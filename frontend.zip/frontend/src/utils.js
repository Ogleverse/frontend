import state from './store/state'
import config from './config'
import axios from 'axios'
import router from './router'

import WebSocketClient from './wsclient'

const utils={

  degreesToRadians(degrees) {
    return degrees/180*Math.PI
  },
  radiansToDegrees (radians) {
    return radians/Math.PI*180
  },
  a2mlin (angleInDegrees) {
    return (angleInDegrees/90 + 1)
  },
  m2alin (multiplier) {
    return (multiplier - 1)*90
  },
  a2m (angleInDegrees) {
    return (1/Math.cos(this.degreesToRadians(angleInDegrees)))
  },
  m2a (multiplier) {
    return this.radiansToDegrees(Math.acos(1/multiplier))
  },
  tick_clock() {
    if (state.gameEndsAt) {
      // let _iOSDevice = !!navigator.platform.match(/iPhone|iPod|iPad/);
      let datestr;
      let actstr
      let date;
      let canActBefore;
      // if (_iOSDevice) {
      //   datestr = state.gameEndsAt.replace(' ', 'T') 
      //   actstr = state.canActBefore.replace(' ', 'T')
      // } else {
      //   datestr = state.gameEndsAt.replace(' ', 'T') + '+0000'
      //   actstr = state.canActBefore.replace(' ', 'T') + '+0000'
      // }   
      datestr = state.gameEndsAt.replace(' ', 'T') + '+0000'
      actstr = state.canActBefore.replace(' ', 'T') + '+0000'
      date = +Date.parse(datestr)/1000;
      canActBefore = +Date.parse(actstr)/1000;
      if (isNaN(date) || isNaN(canActBefore)) {
        datestr = state.gameEndsAt.replace(' ', 'T')
        actstr = state.canActBefore.replace(' ', 'T')
        date = +Date.parse(datestr)/1000;
        canActBefore = +Date.parse(actstr)/1000;
      }
      if (isNaN(date) || isNaN(canActBefore)) {
        datestr = state.gameEndsAt
        actstr = state.canActBefore
        date = +Date.parse(datestr)/1000;
        canActBefore = +Date.parse(actstr)/1000;
      }     
      let now = +Date.now()/1000;
      let dist = date - now;
      let fdist = canActBefore - now;
      let actDist = canActBefore - now;
      let min = parseInt(dist/60);
      let sec = parseInt(dist%60);
      let fmin = parseInt(fdist/60);
      let fsec = parseInt(fdist%60);
      if (min < 10) min = '0' + min;
      if (sec < 10) {
        sec = '0' + sec;
      }
      if (fmin < 10) fmin = '0' + fmin;
      if (fsec < 10) {
        fsec = '0' + fsec;
      }
      if (dist <= 0) {
        state.game.timeToEnd = '🕚';
        state.game.isLocked = true;
        state.game.isReload = true;
        utils.update_game();
        utils.get_player_stats();
      } else if (actDist <= 0) {
        state.game.isLocked = true;
        state.game.timeToEnd = min + ':' + sec;
        state.game.isReload = false;
      } else {
        state.game.isLocked = false;
        state.game.isReload = false;
        state.game.timeToEnd = fmin + ':' + fsec;
      }
    }
  },
  loadTransactions() {
    if (state.okabanchiks.length == 0) {
      state.stats.splice(0, state.stats.length);
      return;
    }
    for (let oidx in state.okabanchiks) {
      let okabanchik = state.okabanchiks[oidx]
      let trByGameId = {};
      let winLoseHistory = [];
      if (state.stats[oidx] === undefined) state.stats[oidx] = [];
       axios.get(config.api+`/okabanchiks/${okabanchik.id}/transactions`).then(res=>{
        this.processChart(res.data.data,okabanchik.id,okabanchik.value)
        for (let transaction of res.data.data) {
            if (transaction.type !== 'win' && transaction.type !== 'bet') continue;
            if (trByGameId[transaction.game_id] === undefined)
                trByGameId[transaction.game_id] = [];
            trByGameId[transaction.game_id].push(transaction)
        }
        for (let gameId of Object.keys(trByGameId)) {
            if (trByGameId[gameId].length == 1) {
                winLoseHistory.push({
                    gameId,
                    'amount': parseFloat(trByGameId[gameId][0].amount)
                })
            } else {
                let winlose = parseFloat(trByGameId[gameId][0].amount) + parseFloat(trByGameId[gameId][1].amount)
                if (winlose == 0) continue;
                winLoseHistory.push({
                    gameId,
                    'amount': winlose
                });
            }
            winLoseHistory.sort((a, b) => {
                return b.gameId - a.gameId
            })
        }
        let oldlength = state.stats[oidx].length;
        winLoseHistory.slice(0,10).forEach(entry=>{
          state.stats[oidx].push(entry.amount)
        })
        state.stats[oidx].splice(0,oldlength);
      })
    }
  },
  processChart(data,id,value) {
    let currentHour;
    let lastHour = null;
    // let lastGame = null;
    let open,close;
    let low, high = 0;
    let roundDiff = 0;
    let startVal = parseFloat(value);
    let val = startVal;
    state.playerStats.charts[id] = [];
    let cnt = 0;  

    for (let transaction of data) {
      if (cnt > 48) return;
      if (transaction.type == 'win') {
        roundDiff += parseFloat(transaction.amount)
      }
      if (transaction.type == 'bet') {
        roundDiff += parseFloat(transaction.amount)
        currentHour = transaction.created_at.slice(11,13) + ':00';
        if (currentHour != lastHour) {
          if (lastHour != null) {
            //open = val;
            let it = {
              x: lastHour,
              y: [parseFloat(open.toFixed(8)), parseFloat(high.toFixed(8)), parseFloat(low.toFixed(8)), parseFloat(close.toFixed(8))]
            }
            state.playerStats.charts[id].unshift(it);
            cnt ++;
          }
          close = val;
          open = val - roundDiff;
          low = Math.min(close,open);
          high = Math.max(close,open);
        } else {
          open = val - roundDiff;
          low = Math.min(low,open);
          high = Math.max(high,open);
        }
        val = val - roundDiff;
        roundDiff = 0;
        lastHour = currentHour;
      }
    }
    let it = {
      x: lastHour,
      y: [parseFloat(open.toFixed(8)), parseFloat(high.toFixed(8)), parseFloat(low.toFixed(8)), parseFloat(close.toFixed(8))]
    }
    state.playerStats.charts[id].unshift(it);
  },
  get_player_stats() {
    axios
    .get('/api/transactions/stats')
    .then(res => {
        // state.playerStats = res.data.data;
        state.updatePlayerStats(res.data.data)
    })
  },
  get_my_stats() {
    // let trByGameId = {};
    // let winLoseHistory = [];
    // axios
    // .get('/api/transactions')
    // .then(res => {
    //     trByGameId = {};
    //     winLoseHistory = [];
    //     for (let transaction of res.data.data) {
    //         if (transaction.type !== 'win' && transaction.type !== 'bet') continue;
    //         if (trByGameId[transaction.game_id] === undefined)
    //             trByGameId[transaction.game_id] = [];
    //         trByGameId[transaction.game_id].push(transaction)
    //     }
    //     for (let gameId of Object.keys(trByGameId)) {
    //         if (trByGameId[gameId].length == 1) {
    //             winLoseHistory.push({
    //                 gameId,
    //                 'amount': parseFloat(trByGameId[gameId][0].amount)
    //             })
    //         } else {
    //             let winlose = parseFloat(trByGameId[gameId][0].amount) + parseFloat(trByGameId[gameId][1].amount)
    //             if (winlose == 0) continue;
    //             winLoseHistory.push({
    //                 gameId,
    //                 'amount': winlose
    //             });
    //         }
    //         winLoseHistory.sort((a, b) => {
    //             return b.gameId - a.gameId
    //         })
    //     }
    //     state.stats.splice(0,state.stats.length);
    //     winLoseHistory.slice(0,10).forEach(entry=>{
    //       state.stats.push(entry.amount)
    //     })
    // })

  },
  internal_clock() {
    if (!state.hasCsrf) {
      axios
        .get(config.csrf)
        .then(() => {
          state.hasCsrf = true;
          utils.update_user()
          utils.update_game()
          WebSocketClient.authenticate()
        })
    } else {
      utils.update_user()
      utils.update_game()
    }
  },
  redirectIfUnauthenticated () {
    if ( router.currentRoute.name != 'Login'
         && router.currentRoute.name != 'Register'
         && router.currentRoute.name != 'reset-password'
         && router.currentRoute.name != 'reset-password-form'
         && router.currentRoute.name != 'RegisterRef'
         && router.currentRoute.name != 'Hello'
         ) router.replace('/hello')
  },
  update_user (force=false) {
    if (!force && Date.now() - state.lastUserUpdate < 60000) {
      return;
    }
    if (!state.hasWallet) {
      axios.get(`${config.api}/wallet`)
        .then((response) => {
          state.wallet.address = response.data.data.address
          state.hasWallet = true;
          utils.update_user()
        })
    } else {
      axios.get(
      `${config.api}/auth/status`,
      ).then(response => {
        state.updateFromUserResponse(response);
        state.isLoggedIn = true;
        state.lastUserUpdate = Date.now()
        WebSocketClient.authenticate()
      }).catch((err) => {
        console.warn(err)
        state.hasWallet = false;
        state.isLoggedIn = false;
        state.lastUserUpdate = 0;
        //~ state.clearStorage()
        //utils.redirectIfUnauthenticated()
      })
    }
    
  },
  update_game() {
    axios.get(
      `${config.api}/game`,
    ).then(response => {
      if (response.data.success) {
        const token = decodeURIComponent(utils.getCookie('XSRF-TOKEN'));
        axios.defaults.headers.common['X-XSRF-TOKEN'] = token;
        axios.defaults.headers.common['X-CSRF-TOKEN'] = token;
        let m = response.data.data;
        if (!state.name) {
          axios.get(
            `${config.api}/user`,
          ).then(response => {
            if (response.data.name) {
              state.name = response.data.name;
            }
          })
        }
        state.updateFromGameResponse(response);
        const okabanchik = response.data.data.okabanchik
        state.angle = utils.m2a(m.my_multiplier)
        state.isLoggedIn = true;
        state.skin_id = response.data.data.investor_skin_id;
        state.meanBet = response.data.data.meanBet;
        state.level = response.data.data.level;
        state.bidsPlaced = okabanchik ? okabanchik.totalBids : 0;
        state.totalPool = okabanchik ? okabanchik.totalPool : 0;
        state.balance = okabanchik ? okabanchik.value : 0;
        state.okabanchik.id = okabanchik ? okabanchik.id : 0
        state.okabanchik.value = okabanchik ? okabanchik.value : 0
        state.okabanchik.maxValue = okabanchik ? okabanchik.max_value : 0;
        state.okabanchik.experience = okabanchik ? okabanchik.experience : 0;
        state.okabanchik.next_level_experience = okabanchik ? okabanchik.next_level_experience : 0;
        state.okabanchik.skin = okabanchik ? okabanchik.skin.name : null
        state.walletBalance = response.data.data.my_wallet_balance;
        state.gameEndsAt = response.data.data.ends_at
        state.canActBefore = response.data.data.can_act_before;
        state.isJoined = response.data.data.is_joined;
        utils.get_my_stats();
        utils.get_player_stats();
        utils.loadTransactions();
        if ( router.currentRoute.name == 'Login' || router.currentRoute.name == 'Register' ) router.replace('/')
      }
    }).catch(error => {
      console.warn(error)
      if (error.response.status == 404) return ()=>{
        if (!state.isUpdating) {
          state.isUpdating = true;
          setTimeout(()=>{utils.update_game();utils.get_player_stats();state.isUpdating = false;},1000)}
        };
      else if (error.response.status == 401) {
        state.isLoggedIn = false;
        state.clearStorage();
        utils.redirectIfUnauthenticated()
      }
      
    })
  },
  getCookie (name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    else if (parts.length === 3) return parts[1];
  }
}

export default utils;
