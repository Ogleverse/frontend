class Provider {
  constructor () {
    this.state = {}
  }

  deepCopy(source, destination) {

  }

  updateFromObject (obj) {

  }
}
