import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import Register from '../views/Register.vue'
import Deposit from '../views/Deposit.vue'
import Withdraw from '../views/Withdraw.vue'
import Hello from '../views/Hello.vue'
import RegisterRef from '../views/Ref.vue'
import SendCoins from '../views/SendCoins.vue'
import Exchange from '../views/Exchange.vue'
import Kabanchik from '../views/Kabanchik.vue'
import RequestPasswordReset from '../views/RequestPasswordReset.vue'
import ChangePassword from '../views/ChangePassword.vue'
import EmailConfirmed from '../views/EmailConfirmed.vue'
import EggShop from '../views/EggShop.vue'
import PopKabanchik from '../views/PopKabanchik.vue'
import WinCO from '../views/WinCO.vue'
import BuyHO from '../views/BuyHO.vue'
import Onboarding from '../views/Onboarding.vue'
import StarterBuy from '../views/StarterBuy.vue'
import Swap from '../views/Swap.vue'
import state from '../store/state.js'

Vue.use(VueRouter)

const routes = [
  {
    path: '/login',
    name: "Login",
    component: Login,
    meta: {
      guest: true,
    },
  },
  {
    path: '/hello',
    name: "Hello",
    component: Hello,
    meta: {
      guest: true,
    },
  },
  {
    path: '/',
    name: 'Home',
    component: Home,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/kabanchik',
    name: 'Kabanchik',
    component: Kabanchik,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/onboarding',
    name: 'Onboarding',
    component: Onboarding,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue'),
    meta: {
      guest: true,
    },
  },
  {
    path: '/register',
    name: "Register",
    component: Register,
    meta: {
      guest: true,
    },
  },
  {
    path: '/deposit',
    name: "Deposit",
    component: Deposit,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/mageshop',
    name: "EggShop",
    component: EggShop,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/starterbuy',
    name: "StarterBuy",
    component: StarterBuy,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/swap',
    name: "Swap",
    component: Swap,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/winclanowner',
    name: "WinCO",
    component: WinCO,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/buyhkabanchik',
    name: "BuyHO",
    component: BuyHO,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/popkabanchik',
    name: "PopKabanchik",
    component: PopKabanchik,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/withdraw',
    name: "Withdraw",
    component: Withdraw,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/exchange',
    name: "Exchange",
    component: Exchange,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/send',
    name: "SendCoins",
    component: SendCoins,
    meta: {
      requiresAuth: true,
    },
  },
  {
    path: '/register/ref/:code',
    name: "RegisterRef",
    component: RegisterRef,
    props: true,
    meta: {
      guest: true,
    },
  },
  {
    path: '/reset-password',
    name: 'reset-password',
    component: RequestPasswordReset,
    meta: {
      guest: true,
    },
  },
  {
    path: '/reset-password/:token',
    name: 'reset-password-form',
    component: ChangePassword,
    props: true,
    meta: {
      guest: true,
    },
  },
  {
    path: '/email-confirmed/:message',
    name: 'email-confirmed-form',
    component: EmailConfirmed,
    props: true,
    meta: {
      guest: true,
    },
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to, from, next) => {
  const currentUser = state.user
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!currentUser.id) {
      next({
        path: '/login',
        params: { nextUrl: to.fullPath }
      })
    } else {
      if (to.matched.some(record => record.meta.is_admin)) {
        if (currentUser.is_admin == 1) {
          next()
        } else {
          next({ path: '/' })
        }
      } else {
        console.log('router.beforeEach to', to);
        if (!currentUser.completed_onboarding && to.name != 'Onboarding') {
          next({name: 'Onboarding'})
        } else if (currentUser.completed_onboarding && !currentUser.start_pack && to.name != 'StarterBuy') {
          next({name: 'StarterBuy'})
        } else {
          next()
        }
      }
    }
  } else if (to.matched.some(record => record.meta.guest)) {
    if (currentUser.id == null) {
      next()
    } else {
      next()
      //~ next({ path: '/' })
    }
  } else {
    next()
  }
})

export default router
