<template>
   <div class="cont" :class="{loaded: loaded}" style="overflow-y: scroll;">
      
      <div class="sw-t">
        <div>
          <div class="header" style="position: absolute">
            <div class="p-name"></div>
            <div class="back-b" @click="back">
              Return
            </div>
          </div>
          <form onsubmit="return false" class="login-form">
            <div class="form-wrap">
              <img @touchstart="dOntouchstart"
                @touchmove="dOntouchmove"
                @touchend="dOntouchend"
                style="transition: opacity 1s ease 0s;
                height: 450px;
                padding: 40px;
                border: 5px dotted white;
                border-radius: 50px;
                display: block;
                margin: 80px auto 10px;
                width: 450px;"
                :src="getImgUrl(currentInvestor)">
                <span data-v-82f71856="" style="font-size: 30px;margin-bottom: 60px;display: block;">Swipe Left/Right to select Investor</span>
              <!-- <div style="margin-bottom: 120px;" class="angle"><img style="transform: scale(-1,1);max-width: 250px;margin-bottom: 110px;display: inline-block;" src="@/assets/kabanchik.png">Обкашлять</div> -->
              <div class="red" v-show="error">{{error}}</div>
              <input style="margin-bottom: 40px;" placeholder="Nickname" v-model="name" type="text" />
              <br />
              <input style="margin-bottom: 40px;" placeholder="E-mail" v-model="email" type="text" />
              <br />
              <input style="margin-bottom: 40px;" placeholder="Password" v-model="password" type="password" />
              <br />
              <input style="margin-bottom: 0px;" placeholder="Repeat Password" v-model="password_confirmation" type="password" />
              <br />
            </div>
            <div class="spacer"></div>
            <div class="form-footer">
              <hr data-v-2a3a0dd2="">
              <div class="red text" v-show="isError">{{message}}</div>
              <button type="button" @click="submit">Create Account</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</template>

<script>
import axios from 'axios';
import state from '../store/state';
import config from '../config';
import router from '../router'
import utils from '../utils'

export default {
  data: () => ({
    state,
    isError: false,
    message: {},
    name: '',
    email: '',
    password: '',
    password_confirmation: '',
    loaded: false,
    currentInvestor: 1,
    maxInvestor: 6,
    swLock: false,
    touchStartX: 0,
    touchStartY: 0
  }),
  mounted () {
    setTimeout(()=>{this.loaded = true;},500);
  },
  methods: {
    getImgUrl(pet) {
      if (pet == null) return;
      var images = require.context('../assets/investor/', false, /\.svg$/)
      //:src="'@/assets/monsters/'+state.kabanchik.skin+'.svg'"
      return images('./' + pet + ".svg")
    },
    depRight () {
      if (this.currentInvestor < this.maxInvestor) {
        this.currentInvestor ++
      } else {
        this.currentInvestor = 1
      }
      this.swLock = true;
    },
    depLeft () {
      if (this.currentInvestor > 1) {
        this.currentInvestor --
      } else {
        this.currentInvestor = this.maxInvestor
      }
      this.swLock = true;
    },
    dOntouchstart(evt) {
        this.touchStartX = evt.touches[0].screenX
        this.touchStartY = evt.touches[0].screenY
    },
    dOntouchmove(evt) {
      evt.preventDefault();
      this.updateCounter(this.touchStartX, evt.touches[0].screenX)
    },
    dOntouchend() {
        this.touchStartX = undefined
        this.touchStartY = undefined
        this.swLock = false;
    },
    updateCounter(startX, endX) {
      let deltaX = startX-endX
      if (this.swLock != true){
        if (deltaX > 0) this.depLeft()
          else this.depRight()
      }
    },
    back () {
      router.replace('/hello')
    },
    submit () {
      this.isError = false;
      axios
        .get(config.csrf)
        .then(() => {
          let data = {
            name: this.name,
            email: this.email,
            password: this.password,
            password_confirmation: this.password_confirmation,
            skin_id: this.currentInvestor,
          };
          let refId = localStorage.getItem('ref_user_id')
          let refCode = localStorage.getItem('ref_code')
          if (refId) {
            data.ref_user_id = refId;
          }
          if (refCode) {
            data.ref_code = refCode;
          }
          axios.post(config.api+'/auth/register', data).then(res => {
            if (res.data.success) {
              this.state.updateFromUserResponse(res);
              utils.update_game()
              this.state.isLoggedIn = true;
              //router.replace('/')
              this.$router.push('/onboarding')
            } else {
              this.message = res.data.message;
              this.isError = true;
            }
          }).catch(error => {
            this.message = error.response.data.message;
            let text = "";
            for (let key in error.response.data.errors) {
              text += `${error.response.data.errors[key].join('; ')} `;
            }
            this.message = this.message + ' ' + text;
            this.isError = true;
          })
        })
    }
  }
}
</script>

<style scoped>
  .header {
    height: 100px;
    width: 100%;
    background: none;
    margin-top: 20px;
    display: block;
    position: relative;
    z-index: 10000;
  }

  .form-wrap {
    flex: 1 0 auto;
  }

  .form-footer {
    flex: 0 0 240px;
  }

  .login-form {
    display: flex;
    flex-direction: column;
    min-height: 100%;
    padding-top: 0.5rem;
    padding-bottom: 2rem;
    justify-content: space-between;
  }

  .men-b {
    float: left;
    margin-left: 40px;
  }

  .w-i-2 {
  position: relative;
  bottom: 40px;
  left: 0px;
  color: white;
  font-family: 'Roboto';
  font-weight: 300;
  font-size: 60px;
  line-height: 80px;
  white-space: nowrap;
  text-align: left;
  top: 0;
  transition: 1.5s ease opacity;
  pointer-events: none;
}

.bot-h .w-i-2 {
  bottom: 40px!important;
  position: absolute;
  top: auto;
}

.w-i-2 span:first-of-type {
  font-size: 46px;
}

  .men-b div:first-of-type {
    background: white;
    height: 5px;
    width: 80px;
    position: absolute;
    bottom: 60px;
  }

  .men-b div:last-of-type {
    background: white;
    height: 5px;
    width: 40px;
    position: absolute;
    bottom: 40px;
  }

  .p-name {
    font-size: 40px;
    color: white;
    font-family: Roboto;
    text-align: center;
    line-height: 100px;
  }

  .back-b {
    font-size: 30px;
    color: #fff;
    font-family: Roboto;
    text-align: center;
    line-height: 100px;
    top: 10px;
    font-weight: 100;
    position: absolute;
    right: 40px;
  }

  .error {color: red}
  .cont {
    opacity: 0;
    transition: opacity .5s ease;
    width: 100vw;
    height: 100%;
  }

  .cont.loaded {
    opacity: 1;
  }

  .text {
    color: white;
    font-family: Roboto;
    font-size: 36px;
    font-weight: 400;
    padding-left: 80px;
    padding-right: 80px;
  }

  .text a {
    color: #00FFE0;
  }

  .sw-t {
    width: 100%;
    height: 100%;
    position: absolute;
    left: 0;
    opacity: 1;
    transition: opacity .5s ease;
    overflow-y:auto;
    overflow-x: hidden;
    padding-bottom: 5px;
    top: 0;
  }

  .sw-t > div {
    margin: auto;
    display: block;
    position: relative;
    height: 100%;
    /*animation: 6s linear 1s infinite forwards k1;*/
  }

  .angle {
    color: #00ffe0;
    height: 200px;
    font-size: 200px;
    font-weight: 700;
    position: relative;
    line-height: 200px;
    margin-bottom: 40px;
    font-family: sans-serif;
  }

  input {
    transition: all .5s ease;
    display: inline-block;
    width: calc(100% - 80px);
    margin-left: 40px;
    margin-right: 40px;
    height: 160px;
    position: relative;
    line-height: 150px;
    text-align: center;
    border: 5px solid #00FFE0;
    font-size: 50px;
    background: none!important;
    color: #00FFE0;
    font-family: Rubik;
    border-radius: 25px;
    font-weight: 400;
  }

  button {
    transition: all .5s ease;
    display: inline-block;
    width: calc(100% - 80px);
    margin-left: 40px;
    margin-right: 40px;
    height: 160px;
    line-height: 150px;
    text-align: center;
    border: 5px solid #00FFE0;
    font-size: 50px;
    background: #00FFE0!important;
    color: #000000;
    font-family: Rubik;
    border-radius: 25px;
    font-weight: 400;
    bottom: 80px;
    left: 0;
  }
</style>
