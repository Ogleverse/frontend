<template>
	<!-- <div >
		<h1>
			You were invited by {{data.name}}
		</h1>
		
		<button class="btn btn-lg btn-primary btn-block" @click="gotoRegister">
			Register
		</button>
	</div> -->

	<div class="cont" :class="{loaded: loaded}">
    <div class="sw-t" v-if="loaded">
      <div>
        <form onsubmit="return false" class="login-form">

          <div style="margin-bottom: 120px;" class="angle"><img style="transform: scale(-1,1);max-width: 250px;margin-bottom: 110px;display: inline-block;" src="@/assets/kabanchik.png">Обкашлять</div>
          <div style="font-size: 46px;margin-bottom: 160px;" class="text">You were invited by {{data.name}}!</div>
          <investor :skin-id="data.investor_skin_id"></investor>
          <button @click="gotoRegister" style="color:#00ffe0;background:none!important">Create Account</button>
        </form>
      </div>
    </div>
  </div>
</template>

<script>
	import axios from 'axios'
	import config from '../config'
	import Investor from '../components/Investor.vue'
	import router from '../router'

	export default {
		data: () => ({
			loaded: false,
			data: {}
		}),
		props: {
			code: String
		},
		components: {
			Investor
		},
		methods: {
			gotoRegister () {
				router.replace('/register')
			}
		},
		mounted () {
			axios
			.get(`${config.api}/auth/register/ref/${this.code}`)
			.then(response => {
				this.data = response.data.data;
				this.loaded = true
				if ('localStorage' in window) {
					localStorage.setItem('ref_user_id', this.data.id)
          localStorage.setItem('ref_code', this.code)
				}
			})
			.catch(err => {
				console.warn("Failed to fetch referrer data", err)
				//this.$router.replace('/hello')
			})
		}
	}
</script>

<style scoped>
	.cont {
    opacity: 0;
    transition: opacity .5s ease;
    width: 100vw;
    position: fixed;
    height: 100%;
  }

  .cont.loaded {
    opacity: 1;
  }

  .angle {
    color: #00ffe0;
    height: 200px;
    font-size: 200px;
    font-weight: 700;
    position: relative;
    line-height: 200px;
    margin-bottom: 30px;
    font-family: sans-serif;
  }

  .text {
    color: white;
    font-family: Roboto;
    font-size: 36px;
    font-weight: 400;
    padding-left: 80px;
    padding-right: 80px;
  }

  .text a {
    color: #00FFE0;
  }

  input {
    transition: all .5s ease;
    display: inline-block;
    width: calc(100% - 80px);
    margin-left: 40px;
    margin-right: 40px;
    height: 160px;
    position: relative;
    line-height: 150px;
    text-align: center;
    border: 5px solid #00FFE0;
    font-size: 50px;
    background: none!important;
    color: #00FFE0;
    font-family: Rubik;
    border-radius: 25px;
    font-weight: 400;
  }

  .sw-t {
    width: 100%;
      height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    opacity: 1;
    transition: opacity .5s ease;
  }

  .sw-t > div {
    margin: auto;
      display: block;
      height: 700px;
      position: relative;
      top: calc(50% - 700px);
      /*animation: 6s linear 1s infinite forwards k1;*/
  }

  button {
    transition: all .5s ease;
    display: inline-block;
    width: calc(100% - 80px);
    margin-left: 40px;
    margin-right: 40px;
    height: 160px;
    line-height: 150px;
    text-align: center;
    border: 5px solid #00FFE0;
    font-size: 50px;
    background: #00FFE0!important;
    color: #000000;
    font-family: Rubik;
    border-radius: 25px;
    font-weight: 400;
    bottom: 80px;
    position: fixed;
    left: 0;
  }
</style>