<template>
  <div class="cont" :class="{loaded: state.isLoggedIn && state.user.balance_oglc !== null}">
    <div class="wall-c" :class="{active: !walletActive}" @click="closemenu">
      <div class="header" style="position: absolute;">
        <div class="back-b" @click="wallet">
        </div>
      </div>
      <div class="tot-b" style="z-index: 10;">
        <!-- <div class="wall-h" style="z-index: 202;">
          <span style="font-size:55px">{{state.name}}'s Wallet</span><br><span style="font-size: 55px;line-height: 60px;" class="yld">0.000576BNB</span>
        </div>
         -->
        <!-- <img style="position: absolute;left: 10%;top: 0px;width: 300px;margin-left: -50px;transform: scaleX(1);" class="egg" :src="getSkinUrl(state.skin_id)"> -->
        <investor style="position: absolute;left:-70px;top:70px" :skin-id="state.user.investor_skin_id"></investor>

        <div class="wall-h" style="margin-top: 40px;z-index: 202;text-align: right;">
          <span style="font-size:55px">{{state.user.name}}'s Wallet</span>
          <br>
          <span class="yld" style="font-size:85px">{{state.user.balance_oglc | formatCoin}}<img style="width:43px" class="cash" src="@/assets/Vector.png"></span>
          <br>
          <span class="yld" style="font-size:55px">{{state.user.balance_bnb | formatCoin}} <img class="cash" src="@/assets/VectorBnb.png"></span>
          <br>
          <span v-if="isCopying" @click="copywallet" style="font-size: 55px;max-width: 500px;text-align: left;display: inline-block;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;position: relative;padding-right: 40px;color: rgb(0, 255, 224);width: 100%;line-height: 70px;">
            Copied...&nbsp;
            <img src="@/assets/copy.svg" style="width: 40px;z-index: 1000;position: absolute;right: 0;top: 10px;">
          </span>
          <span v-else @click="copywallet" style="font-size: 55px;max-width: 500px;text-align: left;display: inline-block;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;position: relative;padding-right: 40px;color: rgb(0, 255, 224);line-height: 70px;">
            {{state.wallet.address}}
            <img src="@/assets/copy.svg" style="width: 40px;z-index: 1000;position: absolute;right: 0;top: 10px;">
          </span>
        </div>
        <!-- <div style="margin-top:30px;font-size: 32px;">{{state.wallet.address}}</div> -->
        <div class="d-w-b" style="margin-top:20px;overflow: hidden;height: 70px;overflow: visible;">
          <div @click="send" style="width: calc(100vw - 80px);height: 70px;line-height: 60px;border-color: #00ffe0;margin-left: -40px">Send Coins</div>
          <!-- <div style="width: calc(50vw - 90px);margin-left: 10px;height: 70px;line-height: 60px;">Exchange</div> -->
        </div>
        <!-- <h2>
          Ref link: {{state.user.ref_link}}
        </h2>
        <h3>
          Ref code: {{state.user.ref_code}}
        </h3>  -->
        <!-- <div style="margin-top: 80px;font-weight:300">
          <div :style="{ bottom: (538 + 100 * ((Math.max(egval/(100),1)-1)/4 + 1)  + 'px!important')}" style="display: inline-block;font-size: 55px;margin-right: 5px;">⥯ <span :class="{'win': convertToBnb(state.playerStats.saldo) > 0, 'lose': convertToBnb(state.playerStats.saldo) < 0}">{{convertToBnb(state.playerStats.saldo)}}</span></div><br>
          <span style="font-size: 30px;">Owned Обкашлятьs Value in Last Month</span>
        </div> -->
        <div v-if="state.kabanchiks[state.game.currentKabanchikIdx]" style="display: block;position: inherit;margin-top: 20px;">
          <div  class="w-i-2" style="position: absolute;z-index: 202;top:0;pointer-events: none;">
            <span style="text-transform: capitalize;">{{state.kabanchiks[state.game.currentKabanchikIdx].skin.rarity}} {{state.kabanchiks[state.game.currentKabanchikIdx].skin.collection}} Обкашлять<img class="cash" src="@/assets/Vector.png"></span>
            <br>
            <span class="yld">{{convertToBnb(state.kabanchiks[state.game.currentKabanchikIdx].value)}}<span v-if="parseFloat(state.kabanchiks[state.game.currentKabanchikIdx].value) > parseFloat(state.kabanchiks[state.game.currentKabanchikIdx].maxValue)"> / </span>
            <span class="lose" v-if="parseFloat(state.kabanchiks[state.game.currentKabanchikIdx].value) > parseFloat(state.kabanchiks[state.game.currentKabanchikIdx].maxValue)" style="font-size: 46px;">{{convertToBnb(state.kabanchiks[state.game.currentKabanchikIdx].maxValue)}}</span></span>
          </div>
          <div class="w-i" style="z-index: 202;top:0;pointer-events: none;">
            <span>&nbsp;</span><br>
            <span
              v-bind:key="idx"
              v-for="(winlose, idx) in state.stats[state.game.currentKabanchikIdx]"
              :class="{'win': winlose > 0, 'lose': winlose < 0, 'yld': idx==0}"
              :style="{'opacity': (1 - 0.23*idx), 'font-size': (idx==0)?'inherit':'46px'}"
              >
                {{convertToBnb(winlose)}}
              <br>
            </span>
          </div>
        </div>
        
      </div>
      <div class="bot-h">
        <div class="angl-c">
          <swiper
            style="bottom: 0;position: absolute;width:  calc(100vw - 160px)"
            ref="mySwiper"
            :slides-per-view="1"
            :space-between="50"
            @swiper="onSwiper"
            @slideChange="onSlideChange"
            :options="swiperOptions"
            >

            <swiper-slide class="slide" v-for="(kabanchik, idx) in state.kabanchiks" :key="kabanchik.id">
              <kabanchik :kabanchik-id="kabanchik.id" :value="parseFloat(state.kabanchiks[idx].value)"></kabanchik>
            </swiper-slide>

            <swiper-slide class="slide" v-if="state && state.kabanchiks && state.kabanchiks.length == 0">
              <kabanchik :manual="{'collection':'basic','type':'egg','rarity':'common','skin':'0.svg','scale':1}"></kabanchik>
            </swiper-slide>

            
            <!-- <swiper-slide class="slide">
              <kabanchik :manual="{'collection':'basic','type':'hkabanchik','rarity':'common','skin':'1.svg','scale':6}"></kabanchik>
              <img src="@/assets/HOGLE.png" style="width: 80%;position: absolute;bottom: 0;margin: 5% 10%;">
            </swiper-slide> -->
            <swiper-slide class="slide">
              <img style="bottom: 0px;width: 920px;margin-left: 250px;" src="@/assets/misc/stand.svg">
            </swiper-slide>
            <swiper-slide class="slide">
              <kabanchik :manual="{'collection':'basic','type':'clanowner','rarity':'common','skin':'1.svg','scale':8}"></kabanchik>
              <img src="@/assets/CLANOWNER.png" style="width: 70%;position: absolute;bottom: 0;margin: 15% 15%;">
            </swiper-slide>
          </swiper>
          
          <div class="w-i" style="z-index: 202;pointer-events: none;" v-if="state.kabanchiks[state.game.currentKabanchikIdx]">
            <span>Yield/Risk</span><br>
            <span>
              {{((1/Math.cos(utils.m2a(state.kabanchiks[state.game.currentKabanchikIdx].multiplier)/180*Math.PI) - 1)*100).toFixed(3)}}%
            </span>
          </div>
          <div class="w-i-2" style="z-index: 202;pointer-events: none;">
            <span>Мои кабанчики</span><br>
            <span>
              <div class="swiper-pagination"></div>
            </span>
          </div>
          
          
        </div>
        <div class="d-w-b" v-if="state.kabanchiks.length == 0">
          <div v-if="state && state.kabanchiks && state.game.currentKabanchikIdx == 0" @click="goBuy"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Buy Обкашлять Egg</div>
          <div v-if="state.game.currentKabanchikIdx - (state.kabanchiks.length) == 1" @click="goBuy"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Enter Mage Shop</div>
          <div v-if="state.game.currentKabanchikIdx - (state.kabanchiks.length) == 2" @click="winco"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Win a Clan Öwner</div>
        </div>
        <div class="d-w-b" v-else>
          <div class="locked-button" v-if="(state.game.currentKabanchikIdx <= state.kabanchiks.length-1) && state.kabanchiks[state.game.currentKabanchikIdx].is_locked"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Processing Обкашлять transaction...</div>
          <div v-else-if="state.game.currentKabanchikIdx <= state.kabanchiks.length-1" @click="goKabanchik"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Manage Обкашлять</div>
          <div v-if="state.game.currentKabanchikIdx - (state.kabanchiks.length-1) == 1" @click="goBuy"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Enter Mage Shop</div>
          <div v-if="state.game.currentKabanchikIdx - (state.kabanchiks.length-1) == 2" @click="winco"><img style="transform: scale(-1,1);" src="@/assets/kabanchik.png"> Win a Clan Öwner</div>
        </div>
        <div class="ctdwn" style="pointer-events: none;">
          <div v-if="!state.game.isLocked">Next Замут in</div>
          <div style="color:#ff0099" v-else><span v-if="state.game.isReload">Starting new Замут</span><span v-else>Computing Замут</span></div>
          <div :class="{locked: state.game.isLocked}" class="clock">{{state.game.timeToEnd}}</div>
        </div>
      </div>
      
    </div>
    <!-- <div class="sw-t opaque" :class="{disabled: !isTutorial && !state.game.isLocked && state.level != -1}">
      <img :class="{disabled: !(isTutorial && state.level != -1) || state.game.isLocked}" src="@/assets/swipe.png">
      <img :class="{disabled: !state.game.isLocked}" src="@/assets/lock.png">
      <img :class="{disabled: state.level != -1 || (state.isLoggedIn && state.level && state.level != -1) || state.game.isLocked }" src="@/assets/egg.png">
    </div> -->
    <div style="text-align: left;width: 100%;height: 100%;padding: 80px;">
      <img style="transform: scale(-1,1);max-width: 250px;margin-bottom: 80px;display: inline-block;" src="@/assets/kabanchik.png">
<!--       <div class="left-menu-text">
        Whitepaper
      </div>
      <div class="left-menu-text" @click="getCoin">
        Get Test Coins
      </div> -->
      <div @click="logout" style="bottom: 80px;position: absolute;" class="left-menu-text">
        Logout
      </div>
    </div>
  </div>
</template>

<script>
// Здесь JS
import axios from 'axios'
import state from '../store/state'
import config from '../config'
import utils from '../utils'
import router from '../router'
import { Swiper, SwiperSlide, directive } from 'vue-awesome-swiper'
import Investor from '../components/Investor.vue'
import Kabanchik from '../components/Kabanchik.vue'

// import style (<= Swiper 5.x)
import 'swiper/css/swiper.css'

// import Vue3TouchEvents from 'vue3-touch-events'

function col2rgb(color) {
    return [(color&0xFF0000)>>16, (color&0xFF00)>>8, color&0xFF];
}

const firstColor = 0xFFFFFF;
const secondColor = 0x00FFE0;
const thirdColor = 0xff0099;
const [r1, g1, b1] = col2rgb(firstColor)
const [r2, g2, b2] = col2rgb(secondColor)
const [r3, g3, b3] = col2rgb(thirdColor)
const MinAngle = 0.0;
const MaxAngle = 90.0;

export default {
  data: () => ({
    utils,
    state,
    activity_state: 'idle',
    currentAnimId: null,
    touchStartX: null,
    touchStartY: null,
    moveStart: false,
    expectedYield: 0.0,
    originalAngle: 0,
    uiColor: null,
    angle: 0.0,
    deposit: 0.0,
    rdy: false,
    lng: 0,
    isTutorial: !JSON.parse(window.localStorage.getItem('tutorial-done')),
    isTutorial2: !JSON.parse(window.localStorage.getItem('tutorial2-done')),
    touchPriority: false,
    timer: null,
    walletActive: false,
    depActive: false,
    withActive: false,
    dwCounter: 0.0,
    origCounter: null,
    isSuccessDW: false,
    size: 1,
    selectEgg: 1,
    maxEgg: 4,
    isCopying: false,
    depLock: false,
    swiperOptions: {
      pagination: {
        el: '.swiper-pagination',
        type: 'custom', //fraction
        renderCustom: function (swiper, current, total) {
          return current + '/' + total;
        }
      },
      onInit: function (swiper) {
        swiper.slideTo(state.game.currentKabanchikIdx)
      },
      initialSlide: state.game.currentKabanchikIdx
      // Some Swiper option/callback...
    }
  }),
  components: {
    Swiper,
    SwiperSlide,
    Investor,
    Kabanchik
  },
  directives: {
      swiper: directive
  },
  computed: {
    swiper() {
      return this.$refs.mySwiper.$swiper
    },
    pWith () {
      if (!this.$refs.monster) return;
        return this.$refs.monster.clientWidth ? this.$refs.monster.clientWidth : 0
    },
    pHeight () {
      if (!this.$refs.monster) return;
        return this.$refs.monster.clientHeight ? this.$refs.monster.clientHeight : 0
    },
    egval () {
      if (this.selectEgg == 1) return 100;
      if (this.selectEgg == 2) return 400;
      if (this.selectEgg == 3) return 750;
      if (this.selectEgg == 4) return 1000;
      return 0;
    },
    egcos () {
      if (this.selectEgg == 1) return 200;
      if (this.selectEgg == 2) return 800;
      if (this.selectEgg == 3) return 1500;
      if (this.selectEgg == 4) return 1750;
      return 0;
    },
    predictSize () {
      return ( parseFloat(this.state.balance) + this.expectedYield ) / parseFloat(this.state.balance);
    },
    balance () {
      return (this.state.balance - 0).toFixed(8);
    },
    k () {
      return  (4 / Math.cos(this.angle/180*Math.PI) - 4) < 30 ? (4 / Math.cos(this.angle/180*Math.PI) - 4) : 30
    }
  },
  watch: {
    'state.kabanchiks': {
      deep: true,
      handler: ()=>{}
    },
    'state.game': {
      handler(){

      },
      deep: true
    },
    'state.user': {
      handler(){
        console.debug('state.user', state)
      },
      deep: true
    },
    'state.isLoggedIn': () => {},
    'state.angle': function (val) {
      if (val){
        if (!this.touchPriority) this.angle = val;
        if (this.balance)
          this.expectedYield = this.balance*(1/Math.cos(this.angle/180*Math.PI) - 1)
        this.update_angle_color();
      }
    },
    'state.balance': function(val) {
        if (this.angle)
          this.expectedYield = val*(1/Math.cos(this.angle/180*Math.PI) - 1)
        this.lng = this.expectedYield / this.balance;
        this.size = (Math.max(this.balance/(this.convertToBnb2(100.0)),1)-1)/4 + 1;
    }
  },
  methods: {
    onboard() {
      this.$router.push('/onboarding')
    },
    goKabanchik () {
      this.$router.push('/kabanchik')
    },
    goBuy () {
      this.$router.push('/mageshop')
    },
    winco () {
      this.$router.push('/winclanowner')
    },
    buyho () {
      this.$router.push('/buyhkabanchik')
    },
    send () {
      this.$router.push('/send')
    },
    onSwiper () {
    },
    onSlideChange () {
      state.game.currentKabanchikIdx = this.swiper.activeIndex;
    },
    convertToBnb (val) {
      return parseFloat(val).toFixed(8);
    },
    convertToBnb2 (val) {
      return (parseFloat(val)  / 35886.34).toFixed(8);
    },
    getImgUrl(pet) {
      if (pet == null) return;
      var images = require.context('../assets/monsters/', false, /\.svg$/)
      //:src="'@/assets/monsters/'+state.kabanchik.skin+'.svg'"
      return images('./' + pet + ".svg")
    },
    getSkinUrl(pet) {
      if (pet == null) return;
      var images = require.context('../assets/investor/', false, /\.svg$/)
      //:src="'@/assets/monsters/'+state.kabanchik.skin+'.svg'"
      return images('./' + pet + ".svg")
    },
    depRight () {
      if (this.selectEgg < this.maxEgg) {
        this.selectEgg ++
      } else {
        this.selectEgg = 1
      }
      this.depLock = true;
    },
    depLeft () {
      if (this.selectEgg > 1) {
        this.selectEgg --
      } else {
        this.selectEgg = this.maxEgg
      }
      this.depLock = true;
    },
    logout() {
      axios
        .get(config.csrf)
        .then(() => {
          axios.post(
            `${config.api}/auth/logout`,
            {
            }
          ).then(() => {
			state.clearStorage();
            state.isLoggedIn = false;
            this.$router.replace('/hello')
          })
        })
    },
    wallet() {
      setTimeout(()=>{this.walletActive = !this.walletActive;},50)
    },
    closemenu() {
      if (this.walletActive) this.walletActive = !this.walletActive;
    },
    dep() {
      this.depActive = !this.depActive;
    },
    withd() {
      this.withActive = !this.withActive;
    },
    update_angle_color() {
      const f1 = Math.abs((this.angle - 45)/45);
      const f2 = 1 - f1;
      const f3 = (this.angle - 45)/45 > 0 ? (this.angle - 45)/45 : 0;
      const f4 = (45 - this.angle)/45 > 0 ? (45 - this.angle)/45 : 0;
      this.uiColor = '#' + parseInt(r1*f4 + r2*f2 + r3*f3 ).toString(16).padStart(2, '0')
                    + parseInt(g1*f4 + g2*f2 + g3*f3 ).toString(16).padStart(2, '0')
                    + parseInt(b1*f4 + b2*f2 + b3*f3 ).toString(16).padStart(2, '0');
    },
    place_bid() {
      axios
        .get(config.csrf)
        .then(() => {
          axios.post(
            `${config.api}/game/join`,
            {
              "multiplier": this.expectedYield/this.balance + 1,
            }
          ).then(response => {
            setTimeout(utils.update_game(),5000);
            if (response.data.success) {
              this.state.isJoined = true;
            } else {
              console.warn(response)
            }
          })
        })
    },
    angleOntouchstart(evt) {
      if (this.state.game.isLocked || this.state.level == -1) return;
        this.originalAngle = this.angle;
        this.touchStartX = evt.touches[0].screenX
        this.touchStartY = evt.touches[0].screenY
        this.touchPriority = true;
    },
    angleOntouchmove(evt) {
      if (!this.moveStart) {
          //HIDE TIP
          this.moveStart = true;
          this.isTutorial = false;
          state.tutorialDone = true;
          window.localStorage.setItem('tutorial-done',true)
      }
      if (this.state.game.isLocked) return;
      evt.preventDefault();
      this.updateAngle(this.touchStartX, this.touchStartY, evt.touches[0].screenX, evt.touches[0].screenY)
      this.touchPriority = true;
      clearTimeout(this.timer)
    },
    angleOntouchend() {
        this.originalAngle = null;
        this.touchStartX = undefined
        this.touchStartY = undefined
        if (this.state.game.isLocked) return;
        this.place_bid()
        this.timer = setTimeout(()=>{this.touchPriority = false;},4000)
    },
    dOntouchstart(evt) {
        this.origCounter = this.dwCounter;
        this.touchStartX = evt.touches[0].screenX
        this.touchStartY = evt.touches[0].screenY
        this.touchPriority = true;
    },
    dOntouchmove(evt) {
      evt.preventDefault();
      if (this.isTutorial2) {
        this.isTutorial2 = false;
        state.tutorial2Done = true;
        window.localStorage.setItem('tutorial2-done',true)
      }
      this.updateCounter(this.touchStartX, this.touchStartY, evt.touches[0].screenX, evt.touches[0].screenY)
    },
    dOntouchend() {
        this.originalCounter = null;
        this.touchStartX = undefined
        this.touchStartY = undefined
        this.depLock = false;
    },
    updateCounter(startX, startY, endX, endY) {
      // const delta = (startY-endY) * 0.0005 * state.walletBalance
      // let counterDelta = Math.sign(delta) * 1.001 ** (Math.abs(delta)/1);
      const delta = startY-endY
      let deltaX = startX-endX
      if (this.depLock != true){
        if (deltaX > 0) this.depLeft()
          else this.depRight()
      }
      const multiplier = Math.sign(delta) * (1.3 ** (Math.abs(delta)/2e4)-1);
      this.dwCounter = Math.max(0, Math.min(this.dwCounter + Math.max(state.walletBalance, 1) * multiplier, state.walletBalance));
      // this.dwCounter = Math.min(state.walletBalance, Math.max(0, this.dwCounter+counterDelta));
      if (this.dwCounter > state.walletBalance) {
          this.dwCounter = state.walletBalance
      }

    },
    updateAngle(startX, startY, endX, endY) {
      //let depoDelta = (startY - endY)/1000;
      //this.deposit = Math.min(this.state.balance, Math.max(0, this.deposit+depoDelta));
      let angleDelta = (endX - startX)/500 + (startY - endY)/500;
      this.angle = Math.min(MaxAngle, Math.max(MinAngle, this.angle+angleDelta));
      this.lng = this.expectedYield / this.balance;
      // calc yield
      if (this.angle == 90.0) {
          this.expectedYield = "Inf"
      } else {
          this.expectedYield = this.balance/(90/this.angle)
      }
      const f1 = Math.abs((this.angle - 45)/45);
      const f2 = 1 - f1;
      const f3 = (this.angle - 45)/45 > 0 ? (this.angle - 45)/45 : 0;
      const f4 = (45 - this.angle)/45 > 0 ? (45 - this.angle)/45 : 0;
      this.uiColor = '#' + parseInt(r1*f4 + r2*f2 + r3*f3 ).toString(16).padStart(2, '0')
                    + parseInt(g1*f4 + g2*f2 + g3*f3 ).toString(16).padStart(2, '0')
                    + parseInt(b1*f4 + b2*f2 + b3*f3 ).toString(16).padStart(2, '0');
      // update graphics
    },
    onFrame() {
        if (this.expectedYield == 'Inf' || this.expectedYield == 0) {
            this.rdy = false;
        } else {
            this.rdy = true;
        }
        this.currentAnimId = window.requestAnimationFrame(this.onFrame);
    },
    deposite () {
      router.replace('/deposit')
    },
    withdraw () {
      router.replace('/withdraw')
    },
    back () {
      this.activity_state = 'idle';
    },
    copywallet() {
      this.isCopying = true;
      this.$clipboard(state.wallet.address)
      navigator.clipboard.writeText(state.wallet.address).then(function() {
        /* clipboard successfully set */
      }, function() {
        /* clipboard write failed */
      });
      setTimeout(()=>{this.isCopying = false},1000)
      // const shareData = {
      //   title: 'MDN',
      //   text: 'Learn web development on MDN!',
      //   url: 'https://developer.mozilla.org'
      // }
      // if (navigator) navigator.share(state.wallet.address)
    },
    getCoin() {
      axios
        .get(config.csrf)
        .then(() => {
          axios
            .get(config.api+'/test-coin')
            .then(() => {
              alert("Test Coin Sent")
            }).catch(error => {
              this.error.message = error.response.data.message
            })
        })
    },
    back2 () {
      this.withActive = false;
      this.depActive = false;
      this.selectEgg = 1
      setTimeout(()=>{this.dwCounter = 0;this.isSuccessDW=false;},500);
    },
    submit () {

    },
    start_game () {
      this.activity_state = 'angle';
    },
    submitDeposit () {
      axios
        .get(config.csrf)
        .then(() => {
          axios
            .post(config.api+'/kabanchik/buy', {type: "egg" + this.selectEgg})
            .then(() => {
              this.isSuccessDW = true;
              setTimeout(()=>{utils.update_game();}, 750)
              setTimeout(()=>{this.back2();}, 250)
            }).catch(error => {
              this.error.message = error.response.data.message
            })
        })
    },
    submitWithdraw () {
      axios
        .get(config.csrf)
        .then(() => {
          axios
            .post(config.api+'/kabanchiks/'+ state.kabanchik.id +'/pop', {})
            .then(() => {
              this.isSuccessDW = true;
              setTimeout(()=>{utils.update_game();}, 750)
              setTimeout(()=>{this.back2();}, 250)
            }).catch(error => {
              this.error.message = error.response.data.message
            })
        })
    },
    wOntouchstart(evt) {
        this.origCounter = this.dwCounter;
        this.touchStartX = evt.touches[0].screenX
        this.touchStartY = evt.touches[0].screenY
        this.touchPriority = true;
    },
    wOntouchmove(evt) {
      evt.preventDefault();
      this.updatewCounter(this.touchStartX, this.touchStartY, evt.touches[0].screenX, evt.touches[0].screenY)
    },
    wOntouchend() {
        this.originalCounter = null;
        this.touchStartX = undefined
        this.touchStartY = undefined
    },
    updatewCounter(startX, startY, endX, endY) {
      const delta = startY-endY
      const multiplier = Math.sign(delta) * (1.3 ** (Math.abs(delta)/2e4)-1);
      this.dwCounter = Math.max(0, Math.min(this.dwCounter + Math.max(state.balance, 1) * multiplier, state.balance));
      // this.dwCounter = Math.min(state.balance, Math.max(0, this.dwCounter+counterDelta));
      if (this.dwCounter > state.balance) {
          this.dwCounter = state.balance
      }
    },
  },
  mounted () {
    utils.internal_clock();
    this.currentAnimId = window.requestAnimationFrame(this.onFrame);
    if (this.state.isJoined) {
      this.balance = this.state.balance;
      this.angle = this.state.angle;
      this.expectedYield = this.balance/Math.cos(this.angle/180*Math.PI) - this.balance
    }
    this.update_angle_color();
  },
  filters: {
    toFixed8 (value) {
      return parseFloat(value).toFixed(8)
    }
  }
}
</script>

<style scoped>

.swiper-pagination-fraction, .swiper-pagination-custom {
  bottom: initial!important;
}

.swiper-pagination {
  text-align: left;
}

.egg.upz {
  z-index: 2000!important;
  position: fixed;
  bottom: 385px;
}

.eye {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 250px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .6;
  background: url('~@/assets/kabanchik.png');
  background-size: contain;
  transform-origin: center center;
  transition: 1s ease opacity;
}

.left-menu-text, .left-menu-text a {
  color: #00ffe0;
  font-family: Rubik;
  font-weight: 400;
  font-size: 45px;
  margin-bottom: 40px;
  text-decoration: none;
}

.eye-2 {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 250px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .6;
  background: url('~@/assets/kabanchik-o.png');
  background-size: contain;
  transform-origin: center center;
  transition: 1s ease opacity;
}

.eye-3 {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 250px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .6;
  background: url('~@/assets/kabanchik-g.png');
  background-size: contain;
  transform-origin: center center;
  transition: 1s ease opacity;
}

.slide {
  width:  calc(100vw - 160px);
  height:  calc(100vw - 160px);
  display: flex;
  flex-grow: 1;
  flex-direction: column-reverse;
  justify-content: flex-start;
  opacity: 0;
  transition: .3s ease all;
}
.slide.swiper-slide-active {
  opacity: 1;
}

.eye-4 {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 250px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .6;
  background: url('~@/assets/kabanchik-bg.png');
  background-size: contain;
  transform-origin: center center;
  transition: 1s ease opacity;
}

.eye-5 {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 250px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .6;
  background: url('~@/assets/kabanchik-b.png');
  background-size: contain;
  transform-origin: center center;
  transition: 1s ease opacity;
}

.eye-pulse {
  position: absolute;
  width: 4px;
  height: 4px;
  left: 50%;
  bottom: 60px;
  margin-left: -2px;
  margin-bottom: -2px;
  background: #fff;
  border-radius: 50%;
  opacity: .3;
  -webkit-animation: pulse2 2s infinite;
  animation: pulse2 2s infinite;
  transform-origin: center center;
}

.buttdw {
  transition: all .5s ease;
  display: inline-block;
  width: calc(100% - 80px);
  margin-left: 40px;
  margin-right: 40px;
  height: 160px;
  line-height: 150px;
  text-align: center;
  border: 5px solid #00FFE0;
  font-size: 46px;
  background: #00FFE0!important;
  color: #000000;
  font-family: Rubik;
  border-radius: 25px;
  font-weight: 400;
  bottom: 180px;
  position: absolute;
  left: 0;
  transition: all .5s ease;
}
.buttdw.locked {
  pointer-events: none!important;
  color: rgb(255, 0, 153);
  border-color: rgb(255, 0, 153);
  background: none!important;
}
.buttdw.success {
  pointer-events: none!important;
  color: #00ffe0;
  background: none!important;
}

.win {
  color: #00ffe0;
}
.win::before {
  content:  '+';
}
.lose {
  color: rgb(255, 0, 153);
}

.clock.locked {
  color: rgb(255, 0, 153);
}

.wall-c {
  overflow: hidden;
  width: 100vw;
  position: absolute;
  height: 100%;
  background: black;
  right: -60vw;
  z-index: 500;
  border-left: white 4px solid;
  transition: 1s all ease;
}

.wall-c.active {
  right: 0;
  border-left: white 0px solid;
}

.wall-c .header, .wall-c .tot-b, .wall-c .bot-h  {
  pointer-events: none;
}

.wall-c.active .header, .wall-c.active .tot-b, .wall-c.active .bot-h  {
  pointer-events: initial;
}

.dep-c {
  width: 100vw;
  position: absolute;
  height: 100%;
  background: black;
  right: -100vw;
  z-index: 500;
  border-left: white 0px solid;
  transition: 1s right ease;
}

.dep-c.active {
  right: 0;
}


.cont {
  opacity: 0;
  transition: opacity .5s ease;
  width: 100vw;
  position: fixed;
  height: 100%;
  pointer-events: none;
}

.cont.loaded {
  opacity: 1;
  pointer-events: initial!important;
}

.header {
  height: 100px;
  width: 100%;
  background: none;
  margin-top: 20px;
  display: block;
  position: relative;
  z-index: 1000;
}

.men-b {
  float: right;
  margin-right: 40px;
  width: 80px;
  height: 80px;
  margin-top: 20px;
  background: #fff;
  border-radius: 50%;
}

.back-b {
  font-weight: 100;
  font-size: 30px;
  color: #fff;
  font-family: Roboto;
  text-align: center;
  line-height: 80px;
  top: -10px;
  position: absolute;
  left: 20px;
}

.visible {
  opacity: 0!important;
}

.invisible {
  opacity: 1!important;
}

.exit-b {
  font-weight: 100;
  font-size: 30px;
  color: #fff;
  font-family: Roboto;
  text-align: center;
  line-height: 100px;
  top: 10px;
  position: absolute;
  left: 40px;
  opacity: 0;
  pointer-events: none;
  transition: .3s ease opacity;
}

.locked-button {
  border-color: rgb(255, 0, 153)!important;
  /*color: rgb(255, 0, 153)!important;*/
}

.exit-b.active {
  pointer-events: initial;
  opacity: 1;
}

.men-b div:first-of-type {
  background: none;
  height: 5px;
  width: 80px;
  position: absolute;
  bottom: 60px;
}

.gen-ball {
  position: absolute;
  bottom: 0;
  left: 50%;
  width: 20px;
  height: 20px;
  margin-left: -10px;
  margin-bottom: -10px;
  background: #fff;
  border-radius: 50%;
  opacity: .3;
}
.gen-ball.pulse {
  opacity: 0.2;
  animation: pulse 2s infinite;
}

@keyframes pulse {
  0% {
    width: 20px;
    height: 20px;
    margin-left: -10px;
    margin-bottom: -10px;
    opacity: 0.2;
  }

  70% {
    width: 30px;
    height: 30px;
    margin-left: -15px;
    margin-bottom: -15px;
    opacity: 0;
  }

  100% {
    width: 20px;
    height: 20px;
    margin-left: -10px;
    margin-bottom: -10px;
    opacity: 0;
  }
}

.men-b div:last-of-type {
  background: none;
  height: 5px;
  width: 40px;
  position: absolute;
  bottom: 40px;
}

.p-name div:first-of-type {
  width: auto;
  display: initial;
  top: 10px;
  position: relative;
  right: 20px;
}

.p-name {
  font-size: 46px;
  color: #fff;
  font-family: Roboto;
  line-height: 100px;
  position: absolute;
  top: 10px;
  text-align: right;
  font-weight: 300;
  width: 100%;
}

.egg.one {
  transition: opacity 1s ease;border: 1px dotted #ffffff;border-radius: 75% 75% 50% 50%;opacity: 1;
}

.d-w-b {
  margin-top: 12px;
  height: 160px;
  width: 100%;
  background: none;
  transition: opacity .5s ease, max-height 1s ease;
  max-height: 160px;
  overflow: hidden;
}

.d-w-b img {
  width: 60px;
}

.d-w-b div:first-of-type img {
  margin-right: 20px;
}

.d-w-b div {
  display: inline-block;
  width: calc(100vw - 80px);
  height: 100%;
  position: relative;
  line-height: 144px;
  text-align: center;
  border: 5px solid;
  font-size: 46px;
  color: #fff;
  font-family: Roboto;
  border-radius: 25px;
  font-weight: 400;
}

.d-w-b div:first-of-type {
  /*margin-left: 40px;*/
  /*margin-right: 8px;*/
  border-color:  #00FFE0;
}

.d-w-b div:last-of-type {
  /*margin-right: 40px;*/
  /*margin-left: 8px;*/
  border-color:  white;
}

.d-w-b.locked {
  max-height: 0;
  pointer-events: none;
}

.d-w-b.locked div:first-of-type {
  /*border-color:  white;*/
}

.wall-h {
  text-align: center;
  width: 100%;
}
.wall-h span {
  color: #fff;
  font-family: Roboto;
  font-weight: 300;
  font-size: 95px;
  line-height: 100px;
  white-space: nowrap;
  text-align: left;
}

.wall-h span:first-of-type {
  font-size: 46px;
}

.tot-b {
  margin-left: 80px;
  margin-right: 80px;
  width: calc(100% - 160px);
  position: relative;
  display: block;
  /*z-index: 100;*/
}

.tot-b .w-i {
  position: absolute;
  top: 0px;
  right: 0;
}

.bot-h {
  position: absolute;
  bottom: 20px;
  width: 100%;
}

.ctdwn {
  width: 100%;
    height: 160px;
    z-index: 501;
    position: relative;
    bottom: 0;
}

.ctdwn div {
  display: inline-block;
  height: 100%;
  position: relative;
  line-height: 150px;
  color: #00FFE0;
  font-family: 'Rubik';
  font-weight: 400;
}

.ctdwn div:first-of-type {
  text-align: left;
  float: left;
  margin-left: 80px;
  font-size: 50px;
}
.ctdwn div:last-of-type {
  text-align: right;
  float:  right;
  margin-right: 80px;
  font-size: 66px;
}

.s-b {
  margin-top: 12px;
  height: 160px;
  width: 100%;
  background: none;
  margin-bottom:  4px;
}

.s-b div.dim {
  background: none!important;
  color: #00FFE0;
  pointer-events: none;
}

.s-b div {
  transition: all .5s ease;
  display: inline-block;
  width: calc(100% - 80px);
  margin-left:  40px;
  margin-right:  40px;
  height: 100%;
  position: relative;
  line-height: 150px;
  text-align: center;
  border: 5px solid #00FFE0;
  font-size: 50px;
  color: #000000;
  background: #00FFE0;
  font-family: Rubik;
  border-radius:  25px;
  font-weight: 400;
}

.g-s {
  margin-left: 80px;
  margin-right: 80px;
  margin-bottom: 90px;
  width: calc(100% - 160px);
  position: relative;
  display: block;
  text-align: left;
}

.g-s div {
  position: relative;
  bottom: 0;
}

.g-s > div:first-of-type {
  margin-bottom: 40px;
}

.g-s div div:first-of-type {
  position: relative;
  color: #fff;
  font-family: Roboto;
  bottom: 40px;
  left: 0;
  font-weight: 300;
  font-size: 46px;
  line-height: 80px;
  white-space: nowrap;
  text-align: left;
  margin-bottom: 0px;
  top: 0;
}

.g-s div div:last-of-type {
  position: relative;
  top: 0;
  color: white;
  font-family: 'Roboto';
  font-weight: 300;
  font-size: 150px;
  line-height: 160px;
}

.g-s-m {
  margin-left: 80px;
  margin-right: 80px;
  margin-bottom: 60px;
  width: calc(100% - 160px);
  position: relative;
  display: block;
  text-align: left;
  height: 40vh;
}

.g-s-m div {
  position: relative;
  bottom: 0;
}

.g-s-m > div:first-of-type {
  margin-bottom: 30px;
  margin-top: 40px;
}

.g-s-m div div:first-of-type {
  position: relative;
  top: 0;
  color: white;
  font-family: Roboto;
  font-size: 28px;
  font-weight: 400;
}

.g-s-m div div:last-of-type {
  position: relative;
  top: 0;
  color: white;
  font-family: 'Roboto';
  font-weight: 300;
  font-size: 75px;
  line-height: 80px;
}

.angl-c {
  width: calc(100vw - 160px);
  height: calc(100vw - 160px);
  background: none;
  margin-left: 80px;
  margin-right: 80px;
  border-bottom: 5px solid white;
  margin-bottom: 40px;
  position: relative;
}

.w-i {
    position: absolute;
    bottom: 0px;
    right: 0px;
    color: white;
    font-family: 'Roboto';
    font-weight: 300;
    font-size: 60px;
    line-height: 80px;
    white-space: nowrap;
    text-align: right;
    margin-bottom: 30px;
    z-index: 202;
    transition: 1.5s ease opacity;
}

.w-i span:first-of-type {
  font-size: 46px;
}

.w-i-2 {
  position: relative;
    bottom: 40px;
    left: 0px;
    color: white;
    font-family: 'Roboto';
    font-weight: 300;
    font-size: 60px;
    line-height: 80px;
    white-space: nowrap;
    text-align: left;
    margin-bottom: 30px;
    top: 0;
    transition: 1.5s ease opacity;
}

.bot-h .w-i-2 {
  bottom: 80px!important;
  position: absolute;
  top: auto;
}

.w-i-2 span:first-of-type {
  font-size: 46px;
}

.cash {
  width: 40px;
  position: relative;
  bottom: 4px;
  left: 10px;
  margin-right: 12px;
}

.the-angl {
  position: absolute;
  right: 0;
  bottom: 0;
  width: calc(100vw - 160px);
  border-bottom: 5px dotted white;
  transform-origin: bottom right;
  opacity: 0.2;
}

.the-angl-2 {
  position: absolute;
  left: 0;
  bottom: 0;
  width: calc(100vw - 160px);
  border-bottom: 5px dotted white;
  transform-origin: bottom left;
  opacity: 0.2;
}

.the-angl div {
  position: relative;
  width: 4px;
  height: 4px;
  left: 0;
  bottom: 0;
  margin-left: -4px;
  margin-bottom: -4px;
  background: #fff;
  border-radius: 50%;
  opacity: .2;
}

.the-angl div.bg {
  opacity: 0.5;
  animation: pulse2 3s infinite;
}

@keyframes pulse2 {

  0% {
    width: 2px;
    height: 2px;
    margin-left: -1px;
    margin-bottom: -1px;
    opacity: 0.3;
  }

  80% {
    width: 6px;
    height: 6px;
    margin-left: -3px;
    margin-bottom: -3px;
    opacity: 0;
  }

  100% {
    width: 2px;
    height: 2px;
    margin-left: -1px;
    margin-bottom: -1px;
    opacity: 0;
  }
}
.radian {
  width: 400px;
  height: 400px;
  position: absolute;
  right: -200px;
  bottom: -200px;
  border-bottom: 5px dotted white;
  border-radius: 50%;
  transform: rotate(207deg);
  border-left: none;
  opacity: 0.2;
}

.radian-2 {
  width: 400px;
  height: 400px;
  position: absolute;
  left: -200px;
  bottom: -200px;
  border-bottom: 5px dotted white;
  border-radius: 50%;
  transform: rotate(207deg);
  border-left: none;
  opacity: 0.2;
}

.sw-t {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  background: #000000bf;
  z-index: 200;
  pointer-events: none;
  transition: opacity .7s ease;
  opacity: 1;
}
.sw-t.disabled {
  opacity: 0;
}
.sw-t img.disabled {
  opacity: 0;
}

.sw-t img {
  margin: auto;
    display: block;
    height: 700px;
    position: absolute;
    top: calc(50% - 350px);
    transition: opacity .5s ease;
    opacity: 1;
  margin: 0 calc( (100vw - 700px)/2 );
    /*animation: 6s linear 1s infinite forwards k1;*/
}

.dep-in {
  width: 100%;
  height: calc(100% - 100px);
  margin-top: 100px;
  background: black;
  z-index: 1000;
  display: block;
  position: fixed;
}

.egg {
  width: 100px;
  position: absolute;
  bottom: 0px;
  left: 50%;
  margin-left: -49px;
  z-index: 20;
  transform-origin: bottom center;
  transform: scale(-1,1);
}

/*.opaque {
    animation: 6s linear 0s infinite forwards k1;
}
.opaque.disabled {
  animation: none!important;
}*/

@keyframes k1 {
    0% { opacity: 0.01; }
    15% { opacity: 0.2; }
    30% { opacity: 0.01; }
    80% { opacity: 0.2; }
    100% { opacity: 0.01; }
}

@keyframes k2 {
    0% { opacity: 0.2; }
    15% { opacity: 0.01; }
    30% { opacity: 0.2; }
    100% { opacity: 0.2; }
}
</style>
