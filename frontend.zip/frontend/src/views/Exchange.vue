<template>
  <div class="cont">
    <div class="header">
        <div class="p-name"></div>
        <div class="back-b" @click="back">
          Back
        </div>
    </div>
     <div class="sw-t" v-if="ratesLoaded">
       <div>
         <form onsubmit="return false" class="login-form">
           <div class="angle">ά</div>
           <div class="red-text" v-show="error">{{error}}</div>
           Rates: {{ rates }}
           <br>
           Amount: <input style="margin-bottom: 20px;" v-model="amount" type="number" />
           <select v-model="from_currency">
             <option value="oglc">OGLC</option>
             <option value="bnb">BNB</option>
           </select>
           <br />
         </form>
         You will receive: {{to_amount}} {{to_currency}}
         <br>
         <div style="font-size: 72px; color: #fff; margin: auto">
           limit: {{ rates.exchangePool }}
         </div>
         <div style="font-size: 72px; color: #fff; margin: auto">
           fee: {{ rates.exchangeFee }}
         </div>
         <br>
         <button type="button" @click="submit">Withdraw</button>
       </div>
     </div>
   </div>
</template>

<script>
import state from '../store/state';
import router from '../router'
import config from '../config';
import axios from 'axios';

export default {
  data: () => ({
    amount: 0.01,
    exchangePool: 0.0,
    exchangeFee: 0.0,
    error: '',
    ratesLoaded: false,
    rates: {},
    state,
    from_currency: 'bnb'
  }),
  watch: {
    'state.user': {
      deep: true,
      handler: ()=>{}
    },
    'rates': {
      deep: true,
      handler: ()=>{}
    },
  },
  computed: {
    to_currency: function() {
      return ({oglc:'bnb', bnb:'oglc'})[this.from_currency];
    },
    to_amount: function() {
      let amount
      if (this.from_currency == 'bnb') {
        amount = parseFloat(this.amount) * parseFloat(this.rates.bnb)
      } else {
        amount = parseFloat(this.amount) / parseFloat(this.rates.bnb)
      }
      amount *= (1 - parseFloat(this.rates.comission));
      return amount.toFixed(18);
    }
  },
  methods: {
    back () {
      router.replace('/')
    },
    submit () {
      axios
        .get(config.csrf)
        .then(() => {
          axios
            .post(config.api+'/wallet/exchange', {
        from_currency: this.from_currency,
        to_currency: this.to_currency,
        amount: this.amount
      })
            .then(() => {
              alert("Success")
              this.$router.replace('/')
            }).catch(error => {
              this.error.message = error.response.data.message
            })
        })
    },
  },
  mounted () {
    axios
    .get(config.api+'/wallet/exchange')
    .then(response => {
      this.rates = response.data.data;
      this.ratesLoaded = true;
    }).catch(() => {})
  }
}
</script>

<style>
</style>
