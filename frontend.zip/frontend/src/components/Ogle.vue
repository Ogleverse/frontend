<template>
	<div class="kabanchik" v-if="loaded">
		<img :style="{width: width + 'px', transform: 'scale('+size+')'}" :class="{flipped: flip}" :src="skinUrl">
		<div v-if="kabanchik && kabanchik.level != -1 && (risk !== null && risk > 0) || ( kabanchik && kabanchik.risk > 0 && risk == null)" style="z-index: 21;" class="eye" :style="{ bottom: 55 + 50 * (size - 1)  + 'px', 'background-color': uiColor, transform: 'scale(' + size * 20 * (k+1) + ')' }"></div>
	</div>
</template>

<script>
	import state from '../store/state'
	import config from '../config'
	import axios from 'axios'

	const baseValue = 1; 

	function col2rgb(color) {
		return [(color&0xFF0000)>>16, (color&0xFF00)>>8, color&0xFF];
	}

	const firstColor = 0xFFFFFF;
	const secondColor = 0x00FFE0;
	const thirdColor = 0xff0099;
	const [r1, g1, b1] = col2rgb(firstColor)
	const [r2, g2, b2] = col2rgb(secondColor)
	const [r3, g3, b3] = col2rgb(thirdColor)

	export default {
		data: () => ({
			state,
			kabanchik: null,
			loaded: false,
			uiColor: null
		}),
		props: {
			kabanchikId: Number,
			scalable: {
				type: Boolean,
				default: true,
			},
			flip: {
				type: Boolean,
				default: false
			},
			width: {
				type: Number,
				default: 100
			},
			manual: {
				type: Object,
				default: null
			},
			value: {
				type: Number,
				default: 1
			},
			k: {
				type: Number,
				default: 0
			},
			risk: {
				type: Object,
				default: null
			},
			// uiColor: {
			// 	type: String,
			// 	default: "#00ffe0"
			// }
		},
		mounted () {
			if (!this.manual) {
				axios.get(`${config.api}/kabanchiks/${this.kabanchikId}`)
				.then(response => {
					this.kabanchik = response.data.data
					this.loaded = true
				})
			} else {
				this.loaded = true
			}
			
		},
		watch: {
			'state.kabanchiks': {
				deep: true,
				handler: function() {
					if (this.kabanchik)
						this.update_angle_color()
				}
			},
		},
		computed: {
			formula () {
				return (this.value/baseValue-1)/512 + 1;//(Math.max(this.value/baseValue,1)-1)/16 + 1
			},
			size: function() {
				if ( this.manual && this.manual["collection"]) {
					return this.scalable
					? (this.flip ? -this.manual['scale'] : this.manual['scale'])
					:  (this.flip ? -1 : 1);
				} else {
					return this.flip ? -this.formula : this.formula;
				}
			},
			skinUrl: function() {
				var images = require.context('../assets/collections/', true, /\.svg$/);
				if (this.kabanchik === null && this.manual === null) {
					return '';
				} else if (this.kabanchik === null && this.manual !== null) {
					return images(`./${this.manual['collection']}/${this.manual['type']}/${this.manual['rarity']}/` + this.manual['skin'])
				} else {
					return images(`./${this.kabanchik.collection}/${this.kabanchik.type}/${this.kabanchik.rarity}/` + this.kabanchik.skin.image)
				}
				
			}
		},
		methods: {
			update_angle_color() {
				const f1 = Math.abs((this.kabanchik.risk - 0.5)/0.5);
				const f2 = 1 - f1;
				const f3 = (this.kabanchik.risk - 0.5)/0.5 > 0 ? (this.kabanchik.risk - 0.5)/0.5 : 0;
				const f4 = (0.5 - this.kabanchik.risk)/0.5 > 0 ? (0.5 - this.kabanchik.risk)/0.5 : 0;
				this.uiColor = '#' + parseInt(r1*f4 + r2*f2 + r3*f3 ).toString(16).padStart(2, '0')
				+ parseInt(g1*f4 + g2*f2 + g3*f3 ).toString(16).padStart(2, '0')
				+ parseInt(b1*f4 + b2*f2 + b3*f3 ).toString(16).padStart(2, '0');
			}
		}
	}
</script>

<style scoped>
	.flipped {
		transform: scaleX(-1);
	}
	img {
		transform-origin: bottom;
	}

	.eye {
		position: absolute;
		width: 4px;
		height: 4px;
		left: 50%;
		bottom: 60px;
		margin-left: -2px;
		margin-bottom: -2px;
		background: #fff;
		border-radius: 50%;
		opacity: .3;
		-webkit-animation: pul2 2s infinite;
		animation: pul2 2s infinite;
		transform-origin: center center;
	}

	@keyframes pul2 {

		0% {
			width: 2px;
			height: 2px;
			margin-left: -1px;
			margin-bottom: -1px;
			opacity: 0.3;
		}

		80% {
			width: 6px;
			height: 6px;
			margin-left: -3px;
			margin-bottom: -3px;
			opacity: 0;
		}

		100% {
			width: 2px;
			height: 2px;
			margin-left: -1px;
			margin-bottom: -1px;
			opacity: 0;
		}
	}
</style>
