<template>
	<div class="investor">
		<img :style="{width: width + 'px'}" :class="{flipped: flip}" :src="skinUrl">
	</div>
</template>

<script>

export default {
	data: () => ({
	}),
	props: {
		skinId: Number,
		flip: {
			type: Boolean,
			default: false
		},
		width: {
			type: Number,
			default: 300
		}
	},
	mounted () {
	},
	computed: {
		skinUrl: function() {
			if (this.skinId === null) {
				return '';
			}
			var images = require.context('../assets/investor/', false, /\.svg$/)
      		
			return images('./' + this.skinId + ".svg")
		}
	},
	methods: {
	}
}
</script>

<style>
	.flipped {
		transform: scaleX(-1);
	}
</style>
