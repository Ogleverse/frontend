import utils from '../utils'

const state = {
  game: {
    isJoined: false,
    id: null,
    gameEndsAt: "",
    canActBefore: "",
    timeToEnd: '',
    bidsPlaced: 0,
    totalPool: 0.0,
    isLocked: false,
    isReload: false,
    currentOkabanchikIdx: 0
  },
  user: {
    id: null,
    name: '',
    investor_skin_id: null,
    balance_oglc: null,
    balance_bnb: null,
    ref_code: "",
    ref_link: "",
    ref_count: 0,
    completed_onboarding: false,
    start_pack: null
  },
  wallet: {
    address: ''
  },
  lastUserUpdate: 0,
  isLoggedIn: false,
  hasCsrf: false,
  hasWallet: false,
  isUpdating: false,

  stats: [],
  tutorialDone: !!JSON.parse(window.localStorage.getItem('tutorial-done')),
  tutorial2Done: !!JSON.parse(window.localStorage.getItem('tutorial2-done')),
  walletBalance: '',
  playerStats: {
    bet: 0.0,
    won: 0.0,
    saldo: 0.0,
    spent: 0.0,
    earned: 0.0,
    period: {
      from: "",
      till: ""
    },
    charts: {}
  },
  okabanchiks: [],
  selectedOkabanchik: -1,
  okabanchik: {
    id: null,
    experience: 0,
    next_level_experience: 0,
    value: 0.0,
    maxValue: 0.0,
    skin: {}
  },
  skin_id: 1,
  level: null,
  meanBet: 0,


  updateSelectedOkabanchik (newValue) {
    //~ console.log('updateSelectedOkabanchik', this.selectedOkabanchik, newValue)
    if (this.selectedOkabanchik == newValue || newValue >= this.okabanchiks.length) {
      return;
    }
    if (newValue < 0 || newValue) {
      this.okabanchik.id = null;
      this.okabanchik.experience = 0;
      this.okabanchik.next_level_experience = 0;
      this.okabanchik.value = 0.0;
      this.okabanchik.maxValue = 0.0;
      //this.okabanchik.skin;
    } else {
      // TODO deep copy
      for (let key of Object.keys(this.okabanchiks[newValue])) {
        if (key == 'skin') {
          if (!this.okabanchik.skin) {
            this.okabanchik.skin = {}
          }
          for (let skinKey of Object.keys(this.okabanchiks[newValue]['skin'])) {
            this.okabanchik.skin[skinKey] = this.okabanchiks[newValue]['skin'][skinKey];
          }
        } else {
          this.okabanchik[key] = this.okabanchiks[newValue][key];
        }
      }
    }
    this.selectedOkabanchik = newValue;
    //~ console.log('updateSelectedOkabanchik@state', this)
  },
  updateFromOkabanchiksArray(okabanchiks) {
    if (!okabanchiks) return;
    //~ console.log('updateFromOkabanchiksArray', okabanchiks);
    const oldLength = this.okabanchiks.length;
    for (let i = 0; i < okabanchiks.length; i++) {
      if (i < oldLength) {
        Object.assign(this.okabanchiks[i], okabanchiks[i]);
      } else {
        this.okabanchiks.push(okabanchiks[i])
      }
      //~ console.log(`Adding okabanchik ${i} id=${okabanchiks[i].id}`);
    }
    if (okabanchiks.length < oldLength) {
      if (this.selectedOkabanchik >= okabanchiks.length) {
        this.updateSelectedOkabanchik(okabanchiks.length - 1);
      }
      this.okabanchiks.splice(okabanchiks.length, oldLength - okabanchiks.length);
    }
    //~ console.log('updateSelectedOkabanchik', this.selectedOkabanchik, this);
    if (this.selectedOkabanchik < 0) {
      this.updateSelectedOkabanchik(0);
    }
  },
  updateFromUserResponse (response) {
    const okabanchik = response.data.data.okabanchik
    this.user.name = response.data.data.name
    this.user.id = response.data.data.id
    this.user.investor_skin_id = response.data.data.investor_skin_id; //TODO XXX FIXME
    this.user.balance_bnb = response.data.data.balance_bnb;
    this.user.balance_oglc = response.data.data.balance_oglc
    this.user.ref_link = response.data.data.ref_link
    this.user.ref_count = response.data.data.ref_count
    this.user.ref_code = response.data.data.ref_code
    this.user.completed_onboarding = response.data.data.completed_onboarding
    this.user.start_pack = response.data.data.start_pack
    this.balance = okabanchik ? okabanchik.value : 0
    this.okabanchik.value = okabanchik ? okabanchik.value : 0
    this.okabanchik.id = okabanchik ? okabanchik.id : 0
    this.okabanchik.maxValue = okabanchik ? okabanchik.max_value : 0
    this.okabanchik.experience = okabanchik ? okabanchik.experience : 0
    this.okabanchik.skin = okabanchik ? okabanchik.skin.name : null
    this.okabanchik.next_level_experience = okabanchik ? okabanchik.next_level_experience : 0
    this.walletBalance = response.data.data.wallet_balance
    this.angle = utils.m2a(response.data.data.multiplier)
    this.updateFromOkabanchiksArray(response.data.data.okabanchiks)
    console.log('SKN',this.okabanchik.skin, this.okabanchiks, this.okabanchik)
    this.store()
  },
  updateFromGameResponse (response) {
    //~ console.log('updateFromGameResponse', response)
    this.updateFromOkabanchiksArray(response.data.data.okabanchiks)
  },
  updatePlayerStats (newStats) {
		if (!newStats) return;
    this.playerStats.chart = newStats.bet
    this.playerStats.bet = newStats.bet
    this.playerStats.won = newStats.won
    this.playerStats.saldo = newStats.saldo
    this.playerStats.spent = newStats.spent
    this.playerStats.earned = newStats.earned
    this.playerStats.period.from = newStats.period.from
    this.playerStats.period.till = newStats.period.till
  },
  store () {
		localStorage.setItem('user', JSON.stringify(this.user))
  },
  load () {
		let cachedUser = JSON.parse(localStorage.getItem('user'))
		if (!cachedUser) {
			return;
		}
		for (let key in cachedUser) {
			this.user[key] = cachedUser[key]
		}
	},
	clearStorage () {
		localStorage.removeItem('user');
	}
};

state.load();


export default state;
console.log(state)
