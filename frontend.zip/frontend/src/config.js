export default {
  "csrf": "/sanctum/csrf-cookie",
  "api": "/api"
}
